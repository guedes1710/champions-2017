export default function Header() {
    return (
        <header>
            <h1>Champions League</h1>
        </header>
    )
}